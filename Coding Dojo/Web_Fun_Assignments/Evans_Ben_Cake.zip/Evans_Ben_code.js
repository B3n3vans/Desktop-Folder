function greeting(){
    return "Hello World";
}
var word = greeting();
console.log(word);             // adding the variable word inside the console log will provide the output "Hello World"